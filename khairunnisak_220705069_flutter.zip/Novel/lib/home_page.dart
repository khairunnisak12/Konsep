import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'detail_screen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RumahBuku'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
            child: SizedBox(
              width: 250,  // Width remains the same
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Cari buku anda',
                  hintStyle: const TextStyle(color: Colors.black38),
                  fillColor: Colors.white,
                  filled: true,
                  contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(20),
                    borderSide: BorderSide.none,
                  ),
                  prefixIcon: const Icon(
                    FontAwesomeIcons.magnifyingGlass,
                    color: Colors.blue,
                    size: 20,  // Adjust the size of the icon
                  ),
                ),
                style: const TextStyle(color: Colors.black),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        color: const Color(0xFFF5F5F5),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              childAspectRatio: 0.7,
            ),
            itemCount: books.length,
            itemBuilder: (context, index) {
              final book = books[index];
              return bookReader(context, book['title']!, book['imagePath']!, book['detail']!, book['synopsis']!);
            },
          ),
        ),
      ),
    );
  }

  Widget bookReader(BuildContext context, String title, String imagePath, String detail, String synopsis) {
    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ClipRRect(
            borderRadius: const BorderRadius.vertical(top: Radius.circular(15)),
            child: Image.asset(imagePath, width: double.infinity, height: 220, fit: BoxFit.cover),
          ),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
                const SizedBox(height: 4),
                Text(
                  detail,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => DetailScreen(
                            title: title,
                            imagePath: imagePath,
                            synopsis: synopsis,
                            recommendedBooks: books,  // Pass the books list here
                          ),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.blue,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: const Text('Read Now', style: TextStyle(fontSize: 12)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// Sample data for books
final List<Map<String, String>> books = [
  {
    'title': 'Hujan',
    'imagePath': 'hujan.jpg',
    'detail': 'A tale of love and survival.',
    'synopsis': 'A heart-wrenching story about love lost and found, set in the backdrop of a rainy season that symbolizes the emotional turbulence of the characters.',
  },
  {
    'title': 'Pulang',
    'imagePath': 'pulang.jpeg',
    'detail': 'A journey of self-discovery.',
    'synopsis': 'A deeply personal exploration of self-identity, as the protagonist embarks on a journey to understand who they truly are, amid the struggles of love and loss.',
  },
  {
    'title': 'Rindu',
    'imagePath': 'rindu.jpg',
    'detail': 'A story of longing and faith.',
    'synopsis': 'A tale of separation and longing, as the protagonist searches for hope, faith, and a reunion with a lost love amidst the trials of life.',
  },
  {
    'title': 'Negeri Para Bedebah',
    'imagePath': 'negeri_para_bedebah.jpg',
    'detail': 'An adventure of politics and intrigue.',
    'synopsis': 'A gripping political thriller set in a world of intrigue and corruption, where power struggles lead to unexpected alliances and betrayals.',
  },
  {
    'title': 'Bumi',
    'imagePath': 'bumi.jpg',
    'detail': 'The beginning of a magical journey.',
    'synopsis': 'The first book in the Bumi series, introducing the world of magical creatures and powerful forces that guide the characters on their heroic quests.',
  },
  {
    'title': 'Bulan',
    'imagePath': 'bulan.jpg',
    'detail': 'Exploration of the moon\'s secrets.',
    'synopsis': 'The second book in the Bumi series, exploring the adventures of Raib, Seli, and Ali on the enchanting Planet Bulan. A tale of courage, teamwork, and sacrifice.',
  },
  {
    'title': 'Matahari',
    'imagePath': 'matahari.jpg',
    'detail': 'Unveiling the mysteries of Matahari.',
    'synopsis': 'The third book in the series, delving into the mystical powers of the Sun, and how the trio faces new challenges and revelations that test their friendship.',
  },
  {
    'title': 'Bintang',
    'imagePath': 'bintang.jpeg',
    'detail': 'A starry adventure of courage.',
    'synopsis': 'An adventure across the stars where the characters must overcome their greatest fears and confront powerful enemies to protect the galaxy.',
  },
  {
    'title': 'Ceros dan Batozar',
    'imagePath': 'ceros_dan_batozar.jpg',
    'detail': 'A story of friendship and bravery.',
    'synopsis': 'A heroic tale about two friends, Ceros and Batozar, who journey through dangerous lands, fighting for justice and the future of their world.',
  },
  {
    'title': 'Komet',
    'imagePath': 'komet.jpeg',
    'detail': 'A thrilling race against time.',
    'synopsis': 'A thrilling space adventure where a group of scientists race against time to prevent a comet from colliding with Earth, discovering alien life along the way.',
  },
  {
    'title': 'Komet Minor',
    'imagePath': 'komet_minor.jpeg',
    'detail': 'Next journey of Komet\'s adventure.',
    'synopsis': 'The sequel to Komet, where the journey continues with new threats and a deeper exploration of the alien civilization encountered in the previous adventure.',
  },
  {
    'title': 'Selena',
    'imagePath': 'selena.jpg',
    'detail': 'The untold story of Selena.',
    'synopsis': 'A compelling narrative about Selena, a young woman who uncovers her mysterious past and fights for her place in a world filled with secrets and conspiracies.',
  },
];

