package com.example.rumah_buku

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
