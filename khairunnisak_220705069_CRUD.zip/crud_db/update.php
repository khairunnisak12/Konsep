<?php
$conn = new mysqli("localhost", "root", "", "crud_db");
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$id = $_GET['id'];

$sql = "SELECT * FROM pendaftar WHERE id = $id";
$result = $conn->query($sql);
$pendaftar = $result->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama = $_POST["nama"];
    $email = $_POST["email"];
    $no_hp = $_POST["no_hp"];
    $jurusan = $_POST["jurusan"];
    $jenis_kelamin = $_POST["jenis_kelamin"];
    $cabang_olahraga = $_POST["cabang_olahraga"];

    $sql = "UPDATE pendaftar SET 
            nama='$nama', 
            email='$email', 
            no_hp='$no_hp', 
            jurusan='$jurusan', 
            jenis_kelamin='$jenis_kelamin', 
            cabang_olahraga='$cabang_olahraga' 
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Pendaftar</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #e0f7fa;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh; 
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #00796b; 
        }

        form {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        input[type="text"], input[type="email"], select, button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #00796b; 
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #00796b; 
            color: white;
            border: none;
            cursor: pointer;
            transition: transform 0.2s;
        }

        button:hover {
            background-color: #004d40;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <form action="update.php?id=<?php echo $pendaftar['id']; ?>" method="post">
        <h2>Perbarui Data Pendaftar</h2>
        Nama: <input type="text" name="nama" value="<?php echo $pendaftar['nama']; ?>" required><br>
        Email: <input type="email" name="email" value="<?php echo $pendaftar['email']; ?>" required><br>
        Telepon: <input type="text" name="no_hp" value="<?php echo $pendaftar['no_hp']; ?>" required><br>
        Jurusan: <input type="text" name="jurusan" value="<?php echo $pendaftar['jurusan']; ?>" required><br>
        Jenis Kelamin:
        <select name="jenis_kelamin" required>
            <option value="Laki-laki" <?php echo $pendaftar['jenis_kelamin'] == 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
            <option value="Perempuan" <?php echo $pendaftar['jenis_kelamin'] == 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
        </select><br>
        Cabang Olahraga: <input type="text" name="cabang_olahraga" value="<?php echo $pendaftar['cabang_olahraga']; ?>" required><br>
        <button type="submit">Perbarui</button>
    </form>
</body>
</html>
