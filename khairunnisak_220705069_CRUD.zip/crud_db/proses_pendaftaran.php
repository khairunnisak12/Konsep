<?php
include 'koneksi.php';

$nama = $_POST['nama'];
$jurusan = $_POST['jurusan'];
$no_hp = $_POST['no_hp'];
$jenis_kelamin = $_POST['jenis_kelamin'];
$email = $_POST['email'];
$cabang_olahraga = $_POST['cabang_olahraga'];

$sql = "INSERT INTO pendaftar (nama, jurusan, no_hp, jenis_kelamin, email, cabang_olahraga) 
        VALUES ('$nama', '$jurusan', '$no_hp', '$jenis_kelamin', '$email', '$cabang_olahraga')";

ob_start();

if ($conn->query($sql) === TRUE) {
    echo "Pendaftaran berhasil disimpan. Anda akan dialihkan dalam 2 detik...";
} else {
    echo "Terjadi kesalahan: " . $conn->error . ". Anda akan dialihkan dalam 2 detik...";
}

ob_flush();
sleep(2);
header("Location: ../form.html");
exit;

?>
