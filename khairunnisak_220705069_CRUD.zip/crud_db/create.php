<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];

    // Koneksi database
    $conn = new mysqli("localhost", "root", "", "crud_db");
    if ($conn->connect_error) {
        die("Koneksi gagal: " . $conn->connect_error);
    }

    // Fungsi input data
    $sql = "INSERT INTO pendaftar (name, email, phone) VALUES ('$name', '$email', '$phone')";

    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create pendaftar</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #e0f7fa; /* Latar belakang biru muda */
            margin: 0;
            height: 100vh; /* Tinggi penuh layar */
            display: flex;
            justify-content: center; /* Posisikan secara horizontal */
            align-items: center; /* Posisikan secara vertikal */
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #00796b; /* Warna teks biru gelap */
        }

        form {
            width: 100%;
            max-width: 400px;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }

        input[type="text"], input[type="email"], button {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #00796b; /* Border warna biru gelap */
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #00796b; /* Tombol warna biru gelap */
            color: white;
            border: none;
            cursor: pointer;
            transition: transform 0.2s; /* Efek transisi */
        }

        button:hover {
            background-color: #004d40; /* Warna tombol saat hover */
            transform: translateY(-2px); /* Efek timbul */
        }
    </style>
</head>
<body>
    <form action="create.php" method="post">
        <h2>Tambahkan Data Pengguna</h2>
        Nama: <input type="text" name="name" required><br>
        Email: <input type="email" name="email" required><br>
        Telepon: <input type="text" name="phone" required><br>
        <button type="submit">Simpan</button>
    </form>
</body>
</html>
