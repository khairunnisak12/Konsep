<?php
session_start();

if (isset($_SESSION['username'])) {
    header("Location: crud_db/index.php");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (($username == 'admin' && $password == 'admin') || ($username == 'root' && $password == 'root')) {
        $_SESSION['username'] = $username;
        
        header("Location: crud_db/index.php");
        exit();
    } else {
        $error = "Username atau Password salah!";
    }
}
?>
